/**
 * Gulp Tasker Version: 1.0
 * Author: CynixLabs
 * 
 * USAGE:
 *
 * Installing node/bower dependencies
 *
 * "npm install"
 * "bower install"
 * 
 * Make sure you install all dependencies of node and bower
 * before executing the command below.
 * 
 * To use this tasker simply run this command on your cmd/terminal "gulp"
 * 
 */

var concat = require('gulp-concat'),
	gulp = require('gulp'),
	sass = require('gulp-sass'),
	sourcemaps = require('gulp-sourcemaps'),
	plumber = require('gulp-plumber'),
	jshint = require('gulp-jshint'),
	minifyCss = require('gulp-minify-css'),
	minifyJs = require('gulp-jsmin'),
	browserSync = require('browser-sync').create(),
	kraken = require('gulp-kraken'),
	using = require('gulp-using'),

	// Your local development server
	proxyServer = '127.0.0.1:8000',

	// Sass output optoins [expanded, compressed, nested, compact]
	cssOutputStyle = 'compressed';

// Static server
gulp.task('browser-sync', function() {
	browserSync.init({
		proxy: proxyServer
	});
});

// Sass task
gulp.task('sass', function() {
	gulp.src('./src/scss/**/*.scss')
		.pipe(plumber())
		.pipe(sourcemaps.init())
		.pipe(sass({outputStyle: cssOutputStyle}).on('error', sass.logError))
		.pipe(sourcemaps.write('./maps'))
		.pipe(gulp.dest('./css'))
		.pipe(browserSync.stream());
});

// Custom scripts jshint and compile
gulp.task('customScripts', function() {
	gulp.src('./src/js/*.js')
		.pipe(jshint())
		.pipe(jshint.reporter('default'))
		.pipe(minifyJs())
		.pipe(concat('./scripts.js'))
		.pipe(gulp.dest('./js'))
		.pipe(browserSync.stream());
});



// Default gulp task this process will remain active and react to your file changes
// you won't need to type it again.
gulp.task('default', ['sass', 'customScripts', 'browser-sync'], function() {
	// Watch for scss changes
	gulp.watch('./src/scss/**/*.scss', function() {
		gulp.start('sass');
	});

	// Watch for custom scripts changes 
	gulp.watch('./src/js/*.js', function() {
		gulp.start('customScripts');
	});

	// Watch for php files changes
	gulp.watch('./**/*.php').on('change', browserSync.reload);
});